import React from 'react';
import { Link } from 'react-router-dom';
import { Clapperboard, Mail, Phone, MapPin, Instagram, Twitter, Facebook } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative z-10 mt-20">
      <div className="py-10 border-t border-space-purple bg-space-black bg-opacity-70 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            {/* Логотип и инфо */}
            <div className="col-span-1">
              <Link to="/" className="flex items-center space-x-2 mb-4">
                <Clapperboard size={24} className="text-neon-pink" />
                <span className="text-xl font-title font-bold">Star <span className="text-neon-blue">Cinema</span></span>
              </Link>
              <p className="text-gray-400 text-sm mb-4">
                Онлайн-платформа для бронирования билетов в кинотеатр с космической атмосферой.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-neon-purple hover:text-neon-pink transition-colors">
                  <Instagram size={20} />
                </a>
                <a href="#" className="text-neon-purple hover:text-neon-pink transition-colors">
                  <Twitter size={20} />
                </a>
                <a href="#" className="text-neon-purple hover:text-neon-pink transition-colors">
                  <Facebook size={20} />
                </a>
              </div>
            </div>

            {/* Навигация */}
            <div className="col-span-1">
              <h3 className="text-white font-bold mb-4">Навигация</h3>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-400 hover:text-neon-blue transition-colors">Главная</Link></li>
                <li><Link to="/profile" className="text-gray-400 hover:text-neon-blue transition-colors">Личный кабинет</Link></li>
                <li><a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">О нас</a></li>
                <li><a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">FAQ</a></li>
              </ul>
            </div>

            {/* Жанры */}
            <div className="col-span-1">
              <h3 className="text-white font-bold mb-4">Жанры</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">Боевики</a></li>
                <li><a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">Драмы</a></li>
                <li><a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">Комедии</a></li>
                <li><a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">Триллеры</a></li>
                <li><a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">Фантастика</a></li>
              </ul>
            </div>

            {/* Контакты */}
            <div className="col-span-1">
              <h3 className="text-white font-bold mb-4">Контакты</h3>
              <ul className="space-y-3">
                <li className="flex items-center space-x-2">
                  <MapPin size={16} className="text-neon-pink" />
                  <span className="text-gray-400">Алматы, ул.Жандосова 55 </span>
                </li>
                <li className="flex items-center space-x-2">
                  <Phone size={16} className="text-neon-pink" />
                  <span className="text-gray-400">+7 (705) 551 18-91</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Mail size={16} className="text-neon-pink" />
                  <span className="text-gray-400">infostarcinema@gmail.com</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-space-purple text-center text-sm text-gray-500">
            <p>© {currentYear} Star Cinema. Все права защищены.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;