import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clapperboard, User, Menu, X, Search } from 'lucide-react';
import { useUser } from '../../context/UserContext';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const location = useLocation();
  const { user, isLoggedIn } = useUser();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-space-black bg-opacity-90 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Логотип */}
          <Link to="/" className="flex items-center space-x-2">
            <motion.div 
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
              className="text-neon-pink"
            >
              <Clapperboard size={32} />
            </motion.div>
            <div>
              <h1 className="text-2xl font-title font-bold text-white">
                Star <span className="text-neon-blue">Cinema</span>
              </h1>
              <p className="text-xs text-neon-purple">Космос кино</p>
            </div>
          </Link>

          {/* Десктопная навигация */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-white hover:text-neon-pink transition-colors">Главная</Link>
            <div className="relative">
              <input
                type="text"
                placeholder="Поиск фильмов..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-space-purple bg-opacity-50 text-white rounded-full pl-10 pr-4 py-2 w-64 border border-neon-purple focus:outline-none focus:border-neon-blue transition-all"
              />
              <Search className="absolute left-3 top-2.5 text-neon-purple" size={18} />
            </div>
            {isLoggedIn ? (
              <Link to="/profile" className="flex items-center space-x-2 text-white hover:text-neon-pink transition-colors">
                <User size={20} />
                <span>{user?.name || 'Профиль'}</span>
              </Link>
            ) : (
              <Link to="/login" className="neon-button pink text-sm">Войти</Link>
            )}
          </nav>

          {/* Мобильный переключатель меню */}
          <button 
            className="md:hidden text-white p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? 'Закрыть меню' : 'Открыть меню'}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Мобильное меню */}
      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="md:hidden glass-effect px-4 py-6 shadow-lg"
        >
          <div className="flex flex-col space-y-4">
            <Link to="/" className="text-white py-2 hover:text-neon-pink transition-colors">Главная</Link>
            <div className="relative">
              <input
                type="text"
                placeholder="Поиск фильмов..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-space-purple bg-opacity-50 text-white rounded-full pl-10 pr-4 py-2 w-full border border-neon-purple focus:outline-none focus:border-neon-blue transition-all"
              />
              <Search className="absolute left-3 top-2.5 text-neon-purple" size={18} />
            </div>
            {isLoggedIn ? (
              <Link to="/profile" className="flex items-center space-x-2 text-white py-2 hover:text-neon-pink transition-colors">
                <User size={20} />
                <span>{user?.name || 'Профиль'}</span>
              </Link>
            ) : (
              <Link to="/login" className="neon-button blue text-center">Войти</Link>
            )}
          </div>
        </motion.div>
      )}
    </header>
  );
};

export default Header;