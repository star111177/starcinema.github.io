import React, { useEffect, useRef } from 'react';

const StarryBackground: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    
    const container = containerRef.current;
    const containerWidth = window.innerWidth;
    const containerHeight = window.innerHeight * 2;
    
    // Очистить существующие звезды
    container.innerHTML = '';
    
    // Создать звезды
    const starCount = Math.floor((containerWidth * containerHeight) / 1500);
    
    for (let i = 0; i < starCount; i++) {
      const star = document.createElement('div');
      
      // Рандомные размеры и позиции
      const size = Math.random() < 0.3 ? 'small' : (Math.random() < 0.8 ? 'medium' : 'large');
      const x = Math.floor(Math.random() * containerWidth);
      const y = Math.floor(Math.random() * containerHeight);
      
      // Добавить классы и стили
      star.classList.add('star', size);
      if (Math.random() < 0.6) {
        star.classList.add('twinkle');
        star.style.animationDelay = `${Math.random() * 4}s`;
      }
      
      star.style.left = `${x}px`;
      star.style.top = `${y}px`;
      
      // Добавить звезду в контейнер
      container.appendChild(star);
    }
    
    // Создать несколько ярких звезд
    for (let i = 0; i < 15; i++) {
      const brightStar = document.createElement('div');
      const x = Math.floor(Math.random() * containerWidth);
      const y = Math.floor(Math.random() * containerHeight);
      
      brightStar.classList.add('star', 'large', 'twinkle');
      brightStar.style.width = '4px';
      brightStar.style.height = '4px';
      brightStar.style.opacity = '1';
      brightStar.style.boxShadow = '0 0 10px 2px rgba(255, 255, 255, 0.7)';
      brightStar.style.left = `${x}px`;
      brightStar.style.top = `${y}px`;
      brightStar.style.animationDelay = `${Math.random() * 4}s`;
      
      container.appendChild(brightStar);
    }
  }, []);

  return <div ref={containerRef} className="fixed inset-0 pointer-events-none z-0" />;
};

export default StarryBackground;