import React, { createContext, useContext, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { Booking, Session } from '../types';
import { useUser } from './UserContext';
import { useMovies } from './MovieContext';

interface BookingContextType {
  bookings: Booking[];
  createBooking: (sessionId: string, seats: string[]) => string | null;
  getBookingById: (id: string) => Booking | undefined;
  getUserBookings: () => Booking[];
  cancelBooking: (id: string) => boolean;
}

const BookingContext = createContext<BookingContextType | undefined>(undefined);

export const BookingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const { user } = useUser();
  const { sessions, movies } = useMovies();

  const createBooking = (sessionId: string, seats: string[]): string | null => {
    if (!user) return null;
    
    const session = sessions.find(s => s.id === sessionId);
    if (!session) return null;
    
    const movie = movies.find(m => m.id === session.movieId);
    if (!movie) return null;
    
    // Проверяем, что места не заняты
    const isAnySeatOccupied = seats.some(seat => 
      session.occupiedSeats.includes(seat)
    );
    
    if (isAnySeatOccupied) return null;
    
    // Создаем новое бронирование
    const newBooking: Booking = {
      id: uuidv4(),
      userId: user.id,
      sessionId,
      movieId: movie.id,
      seats,
      totalPrice: session.price * seats.length,
      bookingDate: new Date().toISOString(),
      status: 'confirmed',
    };
    
    // Добавляем бронирование в список
    setBookings(prevBookings => [...prevBookings, newBooking]);
    
    // Обновляем занятые места для сеанса
    // В реальном приложении это было бы сделано через API
    
    return newBooking.id;
  };

  const getBookingById = (id: string): Booking | undefined => {
    return bookings.find(booking => booking.id === id);
  };

  const getUserBookings = (): Booking[] => {
    if (!user) return [];
    return bookings.filter(booking => booking.userId === user.id);
  };

  const cancelBooking = (id: string): boolean => {
    const bookingIndex = bookings.findIndex(b => b.id === id);
    if (bookingIndex === -1) return false;
    
    const updatedBookings = [...bookings];
    updatedBookings[bookingIndex] = {
      ...updatedBookings[bookingIndex],
      status: 'cancelled',
    };
    
    setBookings(updatedBookings);
    return true;
  };

  return (
    <BookingContext.Provider
      value={{
        bookings,
        createBooking,
        getBookingById,
        getUserBookings,
        cancelBooking,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = (): BookingContextType => {
  const context = useContext(BookingContext);
  if (!context) {
    throw new Error('useBooking must be used within a BookingProvider');
  }
  return context;
};