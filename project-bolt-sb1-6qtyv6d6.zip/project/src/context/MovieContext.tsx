import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import type { Movie, Session, Genre } from '../types';

interface MovieContextType {
  movies: Movie[];
  genres: Genre[];
  sessions: Session[];
  loading: boolean;
  error: string | null;
  getMovieById: (id: string) => Movie | undefined;
  getMoviesByGenre: (genreId: string) => Movie[];
  getSessionsByMovieId: (movieId: string) => Session[];
}

const MovieContext = createContext<MovieContextType | undefined>(undefined);

// Список жанров
const genresList: Genre[] = [
  { id: 'action', name: 'Боевик' },
  { id: 'drama', name: 'Драма' },
  { id: 'comedy', name: 'Комедия' },
  { id: 'thriller', name: 'Триллер' },
  { id: 'scifi', name: 'Фантастика' },
  { id: 'adventure', name: 'Приключения' },
  { id: 'crime', name: 'Криминал' },
];

// Изначальные данные фильмов
const initialMovies: Movie[] = [
  {
    id: uuidv4(),
    title: 'Оппенгеймер',
    originalTitle: 'Oppenheimer',
    posterUrl: 'https://avatars.mds.yandex.net/get-kinopoisk-image/4486454/ad99bf4d-54f6-49b9-8c59-b20f7a749cbf/1920x',
    rating: 8.5,
    year: 2023,
    director: 'Кристофер Нолан',
    duration: 180,
    ageRestriction: '16+',
    genres: ['drama', 'thriller'],
    cast: ['Киллиан Мёрфи', 'Эмили Блант', 'Роберт Дауни мл.'],
    description: 'История американского физика-теоретика Роберта Оппенгеймера, который во время Второй мировой войны руководил Манхэттенским проектом — научно-исследовательской программой, в рамках которой разрабатывалось ядерное оружие.',
    trailerUrl: 'https://www.youtube.com/embed/uYPbbksJxIg',
  },
  {
    id: uuidv4(),
    title: 'Дюна 2',
    originalTitle: 'Dune: Part Two',
    posterUrl: 'https://avatars.mds.yandex.net/get-entity_search/478540/858214722/S134x201_2x',
    rating: 8.7,
    year: 2024,
    director: 'Дени Вильнёв',
    duration: 166,
    ageRestriction: '12+',
    genres: ['scifi', 'adventure', 'drama'],
    cast: ['Тимоти Шаламе', 'Зендея', 'Ребекка Фергюсон'],
    description: 'Продолжение эпической одиссеи Пола Атрейдеса, который объединяется с Чани и фрименами, планируя свою месть силам, уничтожившим его семью.',
    trailerUrl: 'https://www.youtube.com/embed/42RV2e1GyzM',
  },
  {
    id: uuidv4(),
    title: 'Гладиатор 2',
    originalTitle: 'Gladiator II',
    posterUrl: 'https://avatars.mds.yandex.net/get-entity_search/10844871/1154038298/SUx182_2x',
    rating: 8.1,
    year: 2024,
    director: 'Ридли Скотт',
    duration: 145,
    ageRestriction: '16+',
    genres: ['action', 'drama', 'adventure'],
    cast: ['Пол Мескаль', 'Дензел Вашингтон', 'Педро Паскаль'],
    description: 'Продолжение истории о борьбе за власть в Римской империи. Новый герой вступает на арену Колизея, чтобы отомстить за свою семью.',
    trailerUrl: 'https://www.youtube.com/embed/wL3mZn0YeIw',
  },
  {
    id: uuidv4(),
    title: 'Джокер 2',
    originalTitle: 'Joker: Folie à Deux',
    posterUrl: 'https://avatars.mds.yandex.net/get-entity_search/5398564/937013655/S134x201_2x',
    rating: 7.9,
    year: 2024,
    director: 'Тодд Филлипс',
    duration: 140,
    ageRestriction: '18+',
    genres: ['thriller', 'crime', 'drama'],
    cast: ['Хоакин Феникс', 'Леди Гага', 'Зази Битц'],
    description: 'Продолжение истории Артура Флека, который теперь полностью принял образ Джокера и находится в психиатрической лечебнице Аркхем.',
    trailerUrl: 'https://www.youtube.com/embed/6Gqk6ohloTU',
  },
  {
    id: uuidv4(),
    title: 'Всё везде и сразу',
    originalTitle: 'Everything Everywhere All at Once',
    posterUrl: 'https://avatars.mds.yandex.net/get-kinopoisk-image/6201401/4585234d-29b3-430f-be03-d66389fd51d8/3840x',
    rating: 8.9,
    year: 2022,
    director: 'Дэниел Кван, Дэниел Шайнерт',
    duration: 139,
    ageRestriction: '16+',
    genres: ['comedy', 'adventure', 'scifi'],
    cast: ['Мишель Йео', 'Ке Хюи Куан', 'Джейми Ли Кёртис'],
    description: 'Эвелин Вонг, владелица прачечной, внезапно открывает связь с множеством параллельных вселенных и должна использовать свои новые способности, чтобы предотвратить мрачное будущее.',
    trailerUrl: 'https://www.youtube.com/embed/IwCY11PXPbw',
  },
  {
    id: uuidv4(),
    title: 'Бедные-несчастные',
    originalTitle: 'Poor Things',
    posterUrl: 'https://avatars.mds.yandex.net/get-entity_search/8076986/781227827/S600xU_2x',
    rating: 8.2,
    year: 2023,
    director: 'Йоргос Лантимос',
    duration: 141,
    ageRestriction: '18+',
    genres: ['comedy', 'drama', 'scifi'],
    cast: ['Эмма Стоун', 'Марк Руффало', 'Уиллем Дефо'],
    description: 'История молодой женщины Беллы Бакстер, которую вернул к жизни эксцентричный доктор Годвин Бакстер. Готовая узнать больше о мире, Белла убегает с ловким и развратным юристом Дунканом Уэддербёрном.',
    trailerUrl: 'https://www.youtube.com/embed/5gcyP-O4gGo',
  },
  {
    id: uuidv4(),
    title: 'Область тьмы',
    originalTitle: 'Limitless',
    posterUrl: 'https://avatars.mds.yandex.net/get-kinopoisk-image/1900788/0d68bd06-f776-401a-a7b0-35a285f54cc7/1920x',
    rating: 7.4,
    year: 2011,
    director: 'Нил Бёргер',
    duration: 105,
    ageRestriction: '16+',
    genres: ['thriller', 'scifi'],
    cast: ['Брэдли Купер', 'Роберт Де Ниро', 'Эбби Корниш'],
    description: 'Писатель Эдди Морра открывает для себя препарат NZT-48, который позволяет ему использовать 100% возможностей своего мозга, что кардинально меняет его жизнь.',
    trailerUrl: 'https://www.youtube.com/embed/eU0Z_rsZiws',
  },
  {
    id: uuidv4(),
    title: 'Барби',
    originalTitle: 'Barbie',
    posterUrl: 'https://avatars.mds.yandex.net/get-mpic/5151028/2a0000019017e799e9faba7a41f50398c286/orig',
    rating: 7.0,
    year: 2023,
    director: 'Грета Гервиг',
    duration: 114,
    ageRestriction: '12+',
    genres: ['comedy', 'adventure'],
    cast: ['Марго Робби', 'Райан Гослинг', 'Америка Феррера'],
    description: 'Кукла Барби, живущая в Барбиленде, сталкивается с экзистенциальным кризисом и отправляется в реальный мир, чтобы найти истинное счастье.',
    trailerUrl: 'https://www.youtube.com/embed/iq2LPQVoxsA',
  },
];

// Генерация сеансов для фильмов
const generateSessions = (movies: Movie[]): Session[] => {
  const sessions: Session[] = [];
  const today = new Date();
  
  // Форматы кинотеатра
  const formats = ['2D', '3D', 'IMAX', 'ScreenX'];
  
  // Залы кинотеатра
  const halls = [
    { id: '1', name: 'Зал 1 - Стандарт' },
    { id: '2', name: 'Зал 2 - IMAX' },
    { id: '3', name: 'Зал 3 - ScreenX' },
    { id: '4', name: 'Зал 4 - VIP' },
  ];
  
  // Для каждого фильма создаем сеансы на ближайшие 7 дней
  movies.forEach((movie) => {
    for (let day = 0; day < 7; day++) {
      const date = new Date(today);
      date.setDate(date.getDate() + day);
      
      // Случайное количество сеансов в день (2-5)
      const numSessions = 2 + Math.floor(Math.random() * 4);
      
      for (let i = 0; i < numSessions; i++) {
        // Выбираем случайное время с 10:00 до 22:00
        const hour = 10 + Math.floor(Math.random() * 12);
        const minute = [0, 30][Math.floor(Math.random() * 2)]; // 0 или 30 минут
        
        date.setHours(hour, minute, 0, 0);
        
        // Выбираем случайный формат и зал
        const format = formats[Math.floor(Math.random() * formats.length)];
        const hall = halls[Math.floor(Math.random() * halls.length)];
        
        // Базовая цена зависит от популярности фильма (рейтинг) и формата
        let price = 1500 + Math.floor(movie.rating * 150);
        
        // Доплата за форматы
        if (format === '3D') price += 500;
        if (format === 'IMAX') price += 1500;
        if (format === 'ScreenX') price += 1000;
        
        // Доплата за VIP зал
        if (hall.id === '4') price += 2500;
        
        // Генерируем случайную схему зала с доступными и занятыми местами
        const totalSeats = hall.id === '4' ? 40 : (hall.id === '2' ? 120 : 80);
        const occupiedSeats: string[] = [];
        
        // Занимаем от 5% до 40% мест случайным образом
        const occupiedCount = Math.floor(totalSeats * (0.05 + Math.random() * 0.35));
        
        for (let j = 0; j < occupiedCount; j++) {
          let seat;
          do {
            const row = 1 + Math.floor(Math.random() * (totalSeats / 10));
            const col = 1 + Math.floor(Math.random() * 10);
            seat = `${row}-${col}`;
          } while (occupiedSeats.includes(seat));
          
          occupiedSeats.push(seat);
        }
        
        // Создаем сеанс
        sessions.push({
          id: uuidv4(),
          movieId: movie.id,
          date: date.toISOString(),
          format,
          hall,
          price,
          occupiedSeats,
        });
      }
    }
  });
  
  return sessions;
};

export const MovieProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [movies, setMovies] = useState<Movie[]>(initialMovies);
  const [genres, setGenres] = useState<Genre[]>(genresList);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Имитация загрузки данных
    setLoading(true);
    try {
      // Генерация сеансов при инициализации
      const generatedSessions = generateSessions(initialMovies);
      setSessions(generatedSessions);
      setLoading(false);
    } catch (err) {
      setError('Ошибка при загрузке данных');
      setLoading(false);
    }
  }, []);

  const getMovieById = (id: string): Movie | undefined => {
    return movies.find(movie => movie.id === id);
  };

  const getMoviesByGenre = (genreId: string): Movie[] => {
    return movies.filter(movie => movie.genres.includes(genreId));
  };

  const getSessionsByMovieId = (movieId: string): Session[] => {
    return sessions.filter(session => session.movieId === movieId);
  };

  return (
    <MovieContext.Provider
      value={{
        movies,
        genres,
        sessions,
        loading,
        error,
        getMovieById,
        getMoviesByGenre,
        getSessionsByMovieId,
      }}
    >
      {children}
    </MovieContext.Provider>
  );
};

export const useMovies = (): MovieContextType => {
  const context = useContext(MovieContext);
  if (!context) {
    throw new Error('useMovies must be used within a MovieProvider');
  }
  return context;
};