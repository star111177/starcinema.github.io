import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Clock, Calendar, Info, Check } from 'lucide-react';
import { useMovies } from '../context/MovieContext';
import { useBooking } from '../context/BookingContext';
import { useUser } from '../context/UserContext';
import { formatDate, formatTime } from '../utils/formatters';

const BookingPage: React.FC = () => {
  const { movieId } = useParams<{ movieId: string }>();
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('sessionId');
  const navigate = useNavigate();
  
  const { getMovieById, sessions } = useMovies();
  const { createBooking } = useBooking();
  const { isLoggedIn } = useUser();
  
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const movie = movieId ? getMovieById(movieId) : undefined;
  const session = sessions.find(s => s.id === sessionId);
  
  // Редирект если пользователь не авторизован
  useEffect(() => {
    if (!isLoggedIn) {
      navigate('/login', { state: { redirectTo: `/booking/${movieId}?sessionId=${sessionId}` } });
    }
  }, [isLoggedIn, navigate, movieId, sessionId]);
  
  // Если фильм или сеанс не найдены
  if (!movie || !session) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center">
        <h2 className="text-2xl font-bold mb-4">Информация недоступна</h2>
        <p className="text-gray-400 mb-6">К сожалению, данные о фильме или сеансе не найдены.</p>
        <button 
          onClick={() => navigate('/')}
          className="neon-button blue flex items-center"
        >
          <ArrowLeft className="mr-2" size={18} />
          Вернуться на главную
        </button>
      </div>
    );
  }
  
  // Получаем размеры зала
  let rows = 8;
  let seatsPerRow = 10;
  
  if (session.hall.id === '1') { // Стандартный
    rows = 8;
    seatsPerRow = 10;
  } else if (session.hall.id === '2') { // IMAX
    rows = 12;
    seatsPerRow = 10;
  } else if (session.hall.id === '3') { // ScreenX
    rows = 10;
    seatsPerRow = 8;
  } else if (session.hall.id === '4') { // VIP
    rows = 5;
    seatsPerRow = 8;
  }
  
  // Создаем план зала
  const renderHall = () => {
    const hallLayout = [];
    
    // Экран
    hallLayout.push(
      <div key="screen" className="w-full flex flex-col items-center mb-8">
        <div className="w-4/5 h-2 bg-neon-blue rounded-t-lg shadow-[0_0_15px_rgba(0,255,224,0.7)] mb-1"></div>
        <div className="w-4/5 h-10 bg-gradient-to-b from-neon-blue to-transparent rounded-b-lg opacity-30"></div>
        <p className="text-gray-400 mt-2">Экран</p>
      </div>
    );
    
    // Ряды с местами
    for (let row = 1; row <= rows; row++) {
      const rowSeats = [];
      
      // Номер ряда слева
      rowSeats.push(
        <div key={`row-left-${row}`} className="w-8 text-center text-gray-400">
          {row}
        </div>
      );
      
      // Места в ряду
      for (let seat = 1; seat <= seatsPerRow; seat++) {
        const seatId = `${row}-${seat}`;
        const isOccupied = session.occupiedSeats.includes(seatId);
        const isSelected = selectedSeats.includes(seatId);
        
        let seatClass = 'seat ';
        if (isOccupied) {
          seatClass += 'seat-unavailable';
        } else if (isSelected) {
          seatClass += 'seat-selected';
        } else {
          seatClass += 'seat-available';
        }
        
        rowSeats.push(
          <div
            key={seatId}
            className={seatClass}
            onClick={() => {
              if (!isOccupied) {
                setSelectedSeats(prev => 
                  prev.includes(seatId)
                    ? prev.filter(id => id !== seatId)
                    : [...prev, seatId]
                );
              }
            }}
          >
            {seat}
          </div>
        );
      }
      
      // Номер ряда справа
      rowSeats.push(
        <div key={`row-right-${row}`} className="w-8 text-center text-gray-400">
          {row}
        </div>
      );
      
      hallLayout.push(
        <div key={`row-${row}`} className="flex justify-center items-center my-1">
          {rowSeats}
        </div>
      );
    }
    
    return hallLayout;
  };
  
  // Обработка бронирования
  const handleBooking = () => {
    if (selectedSeats.length === 0) return;
    
    setIsSubmitting(true);
    
    // Создаем бронирование
    try {
      const bookingId = createBooking(session.id, selectedSeats);
      
      if (bookingId) {
        navigate(`/confirmation/${bookingId}`);
      } else {
        // Обработка ошибки
        alert('Произошла ошибка при бронировании. Пожалуйста, попробуйте снова.');
        setIsSubmitting(false);
      }
    } catch (error) {
      console.error('Ошибка бронирования:', error);
      alert('Произошла ошибка при бронировании. Пожалуйста, попробуйте снова.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="pb-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        {/* Кнопка "Назад" */}
        <div className="flex items-center mb-6">
          <button
            onClick={() => navigate(`/movie/${movieId}`)}
            className="flex items-center text-gray-400 hover:text-neon-blue transition-colors"
          >
            <ArrowLeft className="mr-1" size={18} />
            Вернуться к фильму
          </button>
        </div>
        
        <div className="cinema-card">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Изображение фильма */}
            <div className="w-full md:w-1/4">
              <div className="aspect-[2/3] rounded-lg overflow-hidden">
                <img 
                  src={movie.posterUrl} 
                  alt={movie.title} 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            
            {/* Информация о фильме и сеансе */}
            <div className="w-full md:w-3/4">
              <h1 className="text-2xl font-bold mb-3">{movie.title}</h1>
              <p className="text-gray-400 mb-4">{movie.originalTitle}</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div className="flex items-center">
                  <Calendar className="text-neon-pink mr-2" size={18} />
                  <span className="text-gray-300">
                    {formatDate(new Date(session.date), 'DD MMMM')}
                  </span>
                </div>
                <div className="flex items-center">
                  <Clock className="text-neon-pink mr-2" size={18} />
                  <span className="text-gray-300">
                    {formatTime(new Date(session.date))}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400">Формат: </span>
                  <span className="text-white">{session.format}</span>
                </div>
                <div>
                  <span className="text-gray-400">Зал: </span>
                  <span className="text-white">{session.hall.name}</span>
                </div>
              </div>
              
              <div className="mb-6">
                <p className="text-gray-400">Стоимость билета: <span className="text-white text-xl font-semibold">{session.price} ₸</span></p>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
      
      {/* План зала */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="mb-8"
      >
        <h2 className="text-2xl font-title font-bold mb-6">Выбор мест</h2>
        
        <div className="cinema-card overflow-x-auto">
          <div className="min-w-[500px]">
            {renderHall()}
          </div>
          
          {/* Легенда */}
          <div className="flex flex-wrap justify-center gap-6 mt-8">
            <div className="flex items-center">
              <div className="seat-available w-6 h-6 mr-2"></div>
              <span className="text-gray-300">Свободно</span>
            </div>
            <div className="flex items-center">
              <div className="seat-selected w-6 h-6 mr-2"></div>
              <span className="text-gray-300">Выбрано</span>
            </div>
            <div className="flex items-center">
              <div className="seat-unavailable w-6 h-6 mr-2"></div>
              <span className="text-gray-300">Занято</span>
            </div>
          </div>
        </div>
      </motion.div>
      
      {/* Сводка бронирования */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        <div className="cinema-card">
          <h2 className="text-2xl font-title font-bold mb-4">Ваше бронирование</h2>
          
          {selectedSeats.length === 0 ? (
            <div className="flex items-center justify-center py-6">
              <Info className="text-neon-blue mr-2" size={24} />
              <p className="text-gray-300">Выберите места для бронирования</p>
            </div>
          ) : (
            <>
              <div className="mb-4">
                <div className="flex flex-wrap gap-2 mb-3">
                  {selectedSeats.sort().map(seat => {
                    const [row, seatNum] = seat.split('-');
                    return (
                      <div key={seat} className="px-3 py-1 bg-neon-pink bg-opacity-20 border border-neon-pink rounded-md text-white">
                        Ряд {row}, Место {seatNum}
                      </div>
                    );
                  })}
                </div>
                
                <div className="flex justify-between items-center border-t border-space-purple pt-4 mt-4">
                  <div>
                    <p className="text-gray-400">Количество билетов: {selectedSeats.length}</p>
                    <p className="text-gray-400">Стоимость: {session.price} ₸ × {selectedSeats.length}</p>
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {(session.price * selectedSeats.length).toLocaleString()} ₸
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button 
                  className={`neon-button pink flex items-center ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
                  onClick={handleBooking}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin mr-2"></div>
                      Обработка...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2" size={18} />
                      Забронировать билеты
                    </>
                  )}
                </button>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default BookingPage;