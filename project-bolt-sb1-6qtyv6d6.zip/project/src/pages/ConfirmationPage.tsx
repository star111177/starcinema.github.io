import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Calendar, Clock, MapPin, Ticket, Download, ArrowLeft, ArrowRight } from 'lucide-react';
import { useBooking } from '../context/BookingContext';
import { useMovies } from '../context/MovieContext';
import { formatDate, formatTime } from '../utils/formatters';

const ConfirmationPage: React.FC = () => {
  const { bookingId } = useParams<{ bookingId: string }>();
  const navigate = useNavigate();
  const { getBookingById } = useBooking();
  const { getMovieById, sessions } = useMovies();
  
  const [loading, setLoading] = useState(true);
  
  const booking = bookingId ? getBookingById(bookingId) : undefined;
  const session = booking ? sessions.find(s => s.id === booking.sessionId) : undefined;
  const movie = booking ? getMovieById(booking.movieId) : undefined;
  
  useEffect(() => {
    // Имитация загрузки данных
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 border-4 border-neon-pink border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-neon-blue text-lg">Подтверждаем бронирование...</p>
        </div>
      </div>
    );
  }
  
  if (!booking || !session || !movie) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center">
        <h2 className="text-2xl font-bold mb-4">Информация о бронировании не найдена</h2>
        <p className="text-gray-400 mb-6">К сожалению, данные о бронировании недоступны.</p>
        <button 
          onClick={() => navigate('/')}
          className="neon-button blue flex items-center"
        >
          <ArrowLeft className="mr-2" size={18} />
          Вернуться на главную
        </button>
      </div>
    );
  }
  
  // Сортируем места
  const sortedSeats = [...booking.seats].sort((a, b) => {
    const [rowA, seatA] = a.split('-').map(Number);
    const [rowB, seatB] = b.split('-').map(Number);
    
    if (rowA !== rowB) {
      return rowA - rowB;
    }
    return seatA - seatB;
  });
  
  return (
    <div className="pb-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="max-w-2xl mx-auto"
      >
        {/* Сообщение об успешном бронировании */}
        <div className="text-center mb-10">
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', delay: 0.2 }}
            className="flex justify-center"
          >
            <CheckCircle size={80} className="text-neon-blue" />
          </motion.div>
          <h2 className="text-3xl font-title font-bold mt-4 mb-2">Билеты забронированы!</h2>
          <p className="text-xl text-gray-300">Ваше бронирование успешно подтверждено</p>
        </div>
        
        {/* Детали бронирования */}
        <div className="cinema-card">
          <h3 className="text-xl font-bold mb-6 text-center">Детали бронирования</h3>
          
          {/* Информация о фильме */}
          <div className="flex items-center gap-4 mb-6">
            <div className="w-1/4">
              <div className="aspect-[2/3] rounded-lg overflow-hidden">
                <img 
                  src={movie.posterUrl} 
                  alt={movie.title} 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="w-3/4">
              <h4 className="text-lg font-semibold mb-1">{movie.title}</h4>
              <p className="text-gray-400 text-sm mb-3">{movie.originalTitle}</p>
              <div className="flex flex-col gap-1 text-sm">
                <div className="flex items-center">
                  <Calendar className="text-neon-pink mr-2" size={16} />
                  <span>{formatDate(new Date(session.date), 'DD MMMM YYYY')}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="text-neon-pink mr-2" size={16} />
                  <span>{formatTime(new Date(session.date))}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="text-neon-pink mr-2" size={16} />
                  <span>{session.hall.name}, {session.format}</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Информация о билетах */}
          <div className="border-t border-b border-space-purple py-4 mb-6">
            <div className="flex items-center mb-3">
              <Ticket className="text-neon-blue mr-2" size={20} />
              <h4 className="text-lg font-semibold">Билеты</h4>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-3">
              {sortedSeats.map(seat => {
                const [row, seatNum] = seat.split('-');
                return (
                  <div key={seat} className="px-3 py-2 bg-space-purple bg-opacity-20 border border-neon-purple rounded-md text-center">
                    <p className="text-xs text-gray-400">Ряд {row}</p>
                    <p className="font-semibold">Место {seatNum}</p>
                  </div>
                );
              })}
            </div>
            
            <div className="flex justify-between mt-4">
              <span className="text-gray-400">Количество билетов:</span>
              <span>{booking.seats.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Стоимость одного билета:</span>
              <span>{session.price} ₸</span>
            </div>
            <div className="flex justify-between font-bold text-lg mt-2">
              <span>Итого:</span>
              <span>{booking.totalPrice} ₸</span>
            </div>
          </div>
          
          {/* Код бронирования */}
          <div className="bg-space-blue bg-opacity-40 p-4 rounded-lg text-center mb-6">
            <p className="text-gray-400 mb-1">Код бронирования</p>
            <p className="text-2xl font-mono font-bold tracking-wider text-neon-pink">
              {booking.id.slice(0, 8).toUpperCase()}
            </p>
            <p className="text-xs text-gray-400 mt-1">
              Предъявите этот код при получении билетов в кинотеатре
            </p>
          </div>
          
          {/* Кнопки */}
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <button 
              className="neon-button blue flex items-center justify-center"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="mr-2" size={18} />
              На главную
            </button>
            <button 
              className="neon-button pink flex items-center justify-center"
              onClick={() => navigate('/profile')}
            >
              Мои билеты
              <ArrowRight className="ml-2" size={18} />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ConfirmationPage;