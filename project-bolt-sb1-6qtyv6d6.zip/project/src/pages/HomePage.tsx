import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Calendar, Clock, Film } from 'lucide-react';
import { useMovies } from '../context/MovieContext';
import { formatDate } from '../utils/formatters';

const HomePage: React.FC = () => {
  const { movies, genres, loading } = useMovies();
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [filteredMovies, setFilteredMovies] = useState(movies);

  useEffect(() => {
    if (selectedGenre) {
      setFilteredMovies(movies.filter(movie => movie.genres.includes(selectedGenre)));
    } else {
      setFilteredMovies(movies);
    }
  }, [selectedGenre, movies]);

  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 border-4 border-neon-pink border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-neon-blue text-lg">Загрузка фильмов...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-6 pb-12">
      {/* Герой-секция */}
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="mb-12"
      >
        <div className="relative rounded-2xl overflow-hidden h-80 sm:h-96 md:h-[450px] w-full">
          <div className="absolute inset-0 bg-gradient-to-r from-space-black via-transparent to-space-black z-10"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-space-black via-transparent to-transparent z-10"></div>
          
          <div className="absolute inset-0 z-0">
            {/* Фоновое изображение */}
            <img 
              src="https://img1.akspic.ru/crops/9/4/8/5/7/175849/175849-tumannost-zvezda-galaktika-tumannost_oriona-mlechnyj_put-3840x2160.jpg" 
              alt="Кинотеатр" 
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="absolute inset-0 z-20 flex flex-col justify-center px-6 sm:px-12 md:px-16 max-w-4xl">
            <motion.h1 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="text-4xl sm:text-5xl md:text-6xl font-title font-bold text-white mb-4"
            >
              Star <span className="text-neon-pink">Cinema</span>
            </motion.h1>
            
            <motion.p 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="text-xl sm:text-2xl text-white opacity-90 mb-6"
            >
              Погрузитесь в космическую атмосферу кино вместе с нами
            </motion.p>
            
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.6 }}
            >
              <Link to="/movie/now" className="neon-button pink mr-4">
                Смотреть сейчас
              </Link>
              <Link to="#schedule" className="neon-button blue">
                Расписание
              </Link>
            </motion.div>
          </div>
        </div>
      </motion.section>

      {/* Фильтр по жанрам */}
      <section className="mb-10">
        <div className="flex flex-wrap gap-2 justify-center">
          <button
            className={`px-4 py-2 rounded-full ${
              selectedGenre === null
                ? 'bg-neon-pink bg-opacity-30 text-white border border-neon-pink'
                : 'bg-space-blue bg-opacity-30 text-gray-300 border border-space-purple hover:border-neon-blue'
            } transition-colors`}
            onClick={() => setSelectedGenre(null)}
          >
            Все фильмы
          </button>
          
          {genres.map((genre) => (
            <button
              key={genre.id}
              className={`px-4 py-2 rounded-full ${
                selectedGenre === genre.id
                  ? 'bg-neon-pink bg-opacity-30 text-white border border-neon-pink'
                  : 'bg-space-blue bg-opacity-30 text-gray-300 border border-space-purple hover:border-neon-blue'
              } transition-colors`}
              onClick={() => setSelectedGenre(genre.id)}
            >
              {genre.name}
            </button>
          ))}
        </div>
      </section>

      {/* Список фильмов */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <h2 className="text-3xl font-title font-bold mb-8 text-center">
          Сейчас в <span className="text-neon-blue">прокате</span>
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {filteredMovies.map((movie) => (
            <Link key={movie.id} to={`/movie/${movie.id}`}>
              <motion.div
                whileHover={{ y: -10 }}
                transition={{ duration: 0.3 }}
                className="cinema-card group h-full flex flex-col"
              >
                <div className="relative aspect-[2/3] rounded-lg overflow-hidden mb-4">
                  <img
                    src={movie.posterUrl}
                    alt={movie.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute top-0 right-0 bg-space-black bg-opacity-80 px-2 py-1 m-2 rounded-md flex items-center">
                    <Star className="text-star-yellow h-4 w-4 mr-1" />
                    <span className="text-white text-sm">{movie.rating.toFixed(1)}</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-space-black to-transparent">
                    <p className="text-sm text-neon-blue">
                      {movie.ageRestriction} • {movie.year}
                    </p>
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold mb-2 group-hover:text-neon-pink transition-colors">
                  {movie.title}
                </h3>
                
                <div className="mt-auto">
                  <p className="text-sm text-gray-400 mb-1">{movie.originalTitle}</p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-300">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1 text-neon-purple" />
                      <span>{movie.duration} мин.</span>
                    </div>
                    
                    <div className="flex items-center">
                      <Film className="h-4 w-4 mr-1 text-neon-purple" />
                      <span>{genres.find(g => g.id === movie.genres[0])?.name || movie.genres[0]}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </motion.section>

      {/* Раздел о преимуществах */}
      <motion.section
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="mt-20"
      >
        <h2 className="text-3xl font-title font-bold mb-12 text-center">
          Почему <span className="text-neon-pink">Star Cinema</span>?
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="cinema-card text-center">
            <div className="w-16 h-16 bg-neon-pink bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar className="h-8 w-8 text-neon-pink" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Удобное бронирование</h3>
            <p className="text-gray-300">Выбирайте любимый фильм, сеанс и место прямо из дома за несколько кликов</p>
          </div>
          
          <div className="cinema-card text-center">
            <div className="w-16 h-16 bg-neon-blue bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Star className="h-8 w-8 text-neon-blue" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Премьеры и новинки</h3>
            <p className="text-gray-300">Первыми смотрите самые ожидаемые фильмы года в премиальном качестве</p>
          </div>
          
          <div className="cinema-card text-center">
            <div className="w-16 h-16 bg-neon-purple bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Film className="h-8 w-8 text-neon-purple" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Космический опыт</h3>
            <p className="text-gray-300">Погрузитесь в атмосферу кино с нашими форматами IMAX, 3D и ScreenX</p>
          </div>
        </div>
      </motion.section>
    </div>
  );
};

export default HomePage;