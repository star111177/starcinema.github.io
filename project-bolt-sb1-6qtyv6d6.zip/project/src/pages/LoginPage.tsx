import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogIn, UserPlus, ArrowLeft } from 'lucide-react';
import { useUser } from '../context/UserContext';

type LocationState = {
  redirectTo?: string;
};

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, register } = useUser();
  
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const redirectTo = (location.state as LocationState)?.redirectTo || '/';
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    try {
      let success;
      
      if (isLogin) {
        success = await login(email, password);
        if (!success) {
          setError('Неверный email или пароль');
        }
      } else {
        if (!name.trim()) {
          setError('Введите имя');
          setIsLoading(false);
          return;
        }
        
        success = await register(name, email, password);
        if (!success) {
          setError('Пользователь с таким email уже существует');
        }
      }
      
      if (success) {
        navigate(redirectTo);
      }
    } catch (err) {
      setError('Произошла ошибка. Пожалуйста, попробуйте снова.');
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <div className="min-h-[70vh] flex items-center justify-center py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <button
          onClick={() => navigate('/')}
          className="flex items-center text-gray-400 hover:text-neon-blue transition-colors mb-6"
        >
          <ArrowLeft className="mr-1" size={18} />
          На главную
        </button>
        
        <div className="cinema-card p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-title font-bold mb-2">
              {isLogin ? 'Вход' : 'Регистрация'}
            </h2>
            <p className="text-gray-400">
              {isLogin 
                ? 'Войдите, чтобы получить доступ к бронированию'
                : 'Создайте аккаунт, чтобы начать бронировать билеты'
              }
            </p>
          </div>
          
          {error && (
            <div className="bg-red-500 bg-opacity-20 text-red-400 px-4 py-3 rounded-md mb-6">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            {!isLogin && (
              <div className="mb-4">
                <label htmlFor="name" className="block text-gray-300 mb-2">Имя</label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-field"
                  placeholder="Иван Иванов"
                  required
                />
              </div>
            )}
            
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-300 mb-2">Email</label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-field"
                placeholder="ivan@example.com"
                required
              />
            </div>
            
            <div className="mb-6">
              <label htmlFor="password" className="block text-gray-300 mb-2">Пароль</label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field"
                placeholder="••••••••"
                required
                minLength={6}
              />
            </div>
            
            <button
              type="submit"
              className={`w-full neon-button pink flex items-center justify-center ${
                isLoading ? 'opacity-70 cursor-not-allowed' : ''
              }`}
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="h-5 w-5 border-2 border-t-transparent border-white rounded-full animate-spin mr-2"></div>
              ) : (
                isLogin ? <LogIn className="mr-2" size={18} /> : <UserPlus className="mr-2" size={18} />
              )}
              {isLogin ? 'Войти' : 'Зарегистрироваться'}
            </button>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-gray-400">
              {isLogin ? 'Нет аккаунта?' : 'Уже есть аккаунт?'}
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setError('');
                }}
                className="ml-2 text-neon-blue hover:text-neon-pink transition-colors"
              >
                {isLogin ? 'Зарегистрироваться' : 'Войти'}
              </button>
            </p>
          </div>
        </div>
        
        <div className="mt-6 text-center text-sm text-gray-500">
          <p>Тестовые данные для входа:</p>
          <p>Email: ivan@example.com</p>
          <p>Пароль: password123</p>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginPage;