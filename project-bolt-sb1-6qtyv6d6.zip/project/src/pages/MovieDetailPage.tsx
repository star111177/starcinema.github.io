import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Clock, Calendar, ArrowLeft, MapPin, Info, Film } from 'lucide-react';
import { useMovies } from '../context/MovieContext';
import { formatDate, formatTime } from '../utils/formatters';

const MovieDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getMovieById, getSessionsByMovieId, genres, loading } = useMovies();
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  
  const movie = id ? getMovieById(id) : undefined;
  const allSessions = id ? getSessionsByMovieId(id) : [];
  
  // Группировка сеансов по датам
  const sessionsByDate = allSessions.reduce<Record<string, typeof allSessions>>((acc, session) => {
    const date = new Date(session.date).toISOString().split('T')[0];
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(session);
    return acc;
  }, {});
  
  // Доступные даты сеансов
  const availableDates = Object.keys(sessionsByDate).sort();
  
  // Устанавливаем первую доступную дату по умолчанию
  useEffect(() => {
    if (availableDates.length > 0 && !selectedDate) {
      setSelectedDate(availableDates[0]);
    }
  }, [availableDates, selectedDate]);
  
  // Отфильтрованные сеансы по выбранной дате
  const filteredSessions = selectedDate ? sessionsByDate[selectedDate] : [];
  
  // Сортировка сеансов по времени
  filteredSessions.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-12 w-12 border-4 border-neon-pink border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-neon-blue text-lg">Загрузка информации о фильме...</p>
        </div>
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold mb-4">Фильм не найден</h2>
        <p className="text-gray-400 mb-6">К сожалению, информация о запрашиваемом фильме недоступна.</p>
        <button 
          onClick={() => navigate('/')}
          className="neon-button blue flex items-center"
        >
          <ArrowLeft className="mr-2" size={18} />
          Вернуться на главную
        </button>
      </div>
    );
  }
  
  // Получаем названия жанров фильма
  const movieGenres = movie.genres.map(genreId => {
    const genre = genres.find(g => g.id === genreId);
    return genre ? genre.name : genreId;
  });

  return (
    <div className="pb-12">
      {/* Верхняя часть с постером и информацией */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="relative mb-12"
      >
        {/* Кнопка "Назад" */}
        <motion.button
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          onClick={() => navigate('/')}
          className="absolute top-4 left-4 z-20 bg-space-black bg-opacity-70 p-2 rounded-full hover:bg-neon-pink hover:bg-opacity-30 transition-colors"
        >
          <ArrowLeft className="text-white" size={20} />
        </motion.button>

        {/* Фоновое изображение с градиентом */}
        <div className="relative h-[50vh] overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src={movie.posterUrl} 
              alt={movie.title} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-space-black via-space-black/70 to-transparent z-10"></div>
        </div>

        {/* Информация о фильме */}
        <div className="relative z-20 max-w-6xl mx-auto px-4 sm:px-6 -mt-60">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Постер */}
            <div className="w-full md:w-1/3 lg:w-1/4">
              <div className="aspect-[2/3] rounded-lg overflow-hidden shadow-xl">
                <img 
                  src={movie.posterUrl} 
                  alt={movie.title} 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Детали фильма */}
            <div className="w-full md:w-2/3 lg:w-3/4">
              <div className="flex items-center mb-3">
                <span className="text-neon-pink font-bold py-1 px-3 rounded-md border border-neon-pink mr-3">
                  {movie.ageRestriction}
                </span>
                <span className="flex items-center text-star-yellow mr-4">
                  <Star className="h-5 w-5 mr-1 fill-current" />
                  <span className="font-bold">{movie.rating.toFixed(1)}</span>
                </span>
                <span className="text-gray-300">{movie.year}</span>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl font-title font-bold mb-2">
                {movie.title}
              </h1>
              <p className="text-gray-400 text-lg mb-6">{movie.originalTitle}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 mb-8">
                <div>
                  <p className="text-gray-400 mb-1">Режиссер:</p>
                  <p className="text-white">{movie.director}</p>
                </div>
                <div>
                  <p className="text-gray-400 mb-1">В ролях:</p>
                  <p className="text-white">{movie.cast.join(', ')}</p>
                </div>
                <div>
                  <p className="text-gray-400 mb-1">Жанр:</p>
                  <p className="text-white">{movieGenres.join(', ')}</p>
                </div>
                <div className="flex items-center">
                  <Clock className="text-neon-purple mr-2" size={18} />
                  <span className="text-white">{movie.duration} мин.</span>
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-2">О фильме</h3>
                <p className="text-gray-300 leading-relaxed">{movie.description}</p>
              </div>

              {/* Трейлер */}
              {movie.trailerUrl && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="mt-6"
                >
                  <button 
                    className="neon-button pink flex items-center"
                    onClick={() => window.open(movie.trailerUrl, '_blank')}
                  >
                    <Film className="mr-2" size={18} />
                    Смотреть трейлер
                  </button>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Расписание сеансов */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="max-w-6xl mx-auto px-4 sm:px-6"
      >
        <h2 className="text-3xl font-title font-bold mb-8">Расписание сеансов</h2>

        {availableDates.length === 0 ? (
          <div className="cinema-card p-8 text-center">
            <Info className="mx-auto mb-4 text-neon-blue" size={32} />
            <h3 className="text-xl font-semibold mb-2">Нет доступных сеансов</h3>
            <p className="text-gray-300">К сожалению, сейчас нет доступных сеансов для этого фильма.</p>
          </div>
        ) : (
          <>
            {/* Календарь дат */}
            <div className="mb-8 overflow-x-auto pb-2">
              <div className="flex space-x-3">
                {availableDates.map((date) => {
                  const dateObj = new Date(date);
                  const isToday = new Date().toISOString().split('T')[0] === date;
                  const isSelected = selectedDate === date;
                  
                  return (
                    <button
                      key={date}
                      onClick={() => setSelectedDate(date)}
                      className={`flex-shrink-0 w-20 px-2 py-3 rounded-lg ${
                        isSelected 
                          ? 'bg-neon-pink bg-opacity-30 text-white border border-neon-pink' 
                          : 'bg-space-blue bg-opacity-50 text-gray-300 border border-space-purple hover:border-neon-blue'
                      } transition-colors`}
                    >
                      <p className="text-xs mb-1">{formatDate(dateObj, 'ddd')}</p>
                      <p className="text-xl font-bold">{dateObj.getDate()}</p>
                      <p className="text-xs">{formatDate(dateObj, 'MMM')}</p>
                      {isToday && (
                        <p className="text-xs mt-1 text-neon-blue">Сегодня</p>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Сеансы на выбранную дату */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSessions.map((session) => (
                <div
                  key={session.id}
                  className="cinema-card flex flex-col"
                >
                  <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center">
                      <Clock className="text-neon-blue mr-2" size={16} />
                      <span className="text-xl font-semibold">{formatTime(new Date(session.date))}</span>
                    </div>
                    <span className="px-3 py-1 bg-space-purple bg-opacity-70 rounded-full text-sm">
                      {session.format}
                    </span>
                  </div>

                  <div className="flex items-center mb-3">
                    <MapPin className="text-neon-purple mr-1" size={16} />
                    <span className="text-gray-300">{session.hall.name}</span>
                  </div>

                  <div className="flex justify-between items-center mt-auto">
                    <p className="text-xl font-semibold text-white">{session.price} ₸</p>
                    <Link
                      to={`/booking/${movie.id}?sessionId=${session.id}`}
                      className="neon-button blue text-sm"
                    >
                      Выбрать места
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </motion.section>
    </div>
  );
};

export default MovieDetailPage;