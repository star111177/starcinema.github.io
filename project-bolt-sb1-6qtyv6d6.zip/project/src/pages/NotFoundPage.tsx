import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';

const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', delay: 0.2 }}
        >
          <h1 className="text-8xl font-title font-bold mb-4 text-neon-pink">404</h1>
        </motion.div>
        
        <h2 className="text-3xl font-title font-bold mb-4">Страница не найдена</h2>
        <p className="text-gray-400 mb-8 max-w-md mx-auto">
          Кажется, вы пытаетесь посетить страницу, которая находится в другой галактике.
        </p>
        
        <Link to="/" className="neon-button blue flex items-center justify-center mx-auto w-48">
          <ArrowLeft className="mr-2" size={18} />
          На главную
        </Link>
      </motion.div>
    </div>
  );
};

export default NotFoundPage;