import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Ticket, Calendar, Clock, ArrowLeft, LogOut, MapPin, AlertTriangle } from 'lucide-react';
import { useUser } from '../context/UserContext';
import { useBooking } from '../context/BookingContext';
import { useMovies } from '../context/MovieContext';
import { formatDate, formatTime } from '../utils/formatters';

const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isLoggedIn, logout } = useUser();
  const { getUserBookings, cancelBooking } = useBooking();
  const { getMovieById, sessions } = useMovies();
  
  const [activeTab, setActiveTab] = useState<'active' | 'history'>('active');
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  
  // Редирект на страницу логина, если пользователь не авторизован
  if (!isLoggedIn) {
    navigate('/login', { state: { redirectTo: '/profile' } });
    return null;
  }
  
  const bookings = getUserBookings();
  
  // Фильтрация броней
  const activeBookings = bookings.filter(booking => {
    const session = sessions.find(s => s.id === booking.sessionId);
    if (!session) return false;
    
    // Проверяем, что сеанс еще не начался и бронь не отменена
    return new Date(session.date) > new Date() && booking.status === 'confirmed';
  });
  
  const historyBookings = bookings.filter(booking => {
    const session = sessions.find(s => s.id === booking.sessionId);
    if (!session) return false;
    
    // Проверяем, что сеанс уже прошел или бронь отменена
    return new Date(session.date) <= new Date() || booking.status === 'cancelled';
  });
  
  const handleLogout = () => {
    setIsLoggingOut(true);
    setTimeout(() => {
      logout();
      navigate('/');
    }, 500);
  };
  
  const handleCancelBooking = (bookingId: string) => {
    if (window.confirm('Вы уверены, что хотите отменить бронирование?')) {
      cancelBooking(bookingId);
    }
  };
  
  const renderBookingCard = (bookingId: string) => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return null;
    
    const movie = getMovieById(booking.movieId);
    const session = sessions.find(s => s.id === booking.sessionId);
    
    if (!movie || !session) return null;
    
    const isPast = new Date(session.date) <= new Date();
    const isCancelled = booking.status === 'cancelled';
    
    return (
      <motion.div
        key={booking.id}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="cinema-card"
      >
        {isCancelled && (
          <div className="bg-red-500 bg-opacity-20 text-red-400 px-3 py-2 rounded-md flex items-center mb-4">
            <AlertTriangle size={18} className="mr-2" />
            Бронирование отменено
          </div>
        )}
        
        <div className="flex items-center gap-4 mb-4">
          <div className="w-1/4 sm:w-1/5">
            <div className="aspect-[2/3] rounded-lg overflow-hidden">
              <img 
                src={movie.posterUrl} 
                alt={movie.title} 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          <div className="w-3/4 sm:w-4/5">
            <h3 className="text-lg font-semibold mb-1">{movie.title}</h3>
            <p className="text-gray-400 text-sm mb-3">{movie.originalTitle}</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-4 text-sm">
              <div className="flex items-center">
                <Calendar className="text-neon-pink mr-2" size={16} />
                <span>{formatDate(new Date(session.date), 'DD MMMM YYYY')}</span>
              </div>
              <div className="flex items-center">
                <Clock className="text-neon-pink mr-2" size={16} />
                <span>{formatTime(new Date(session.date))}</span>
              </div>
              <div className="flex items-center">
                <MapPin className="text-neon-pink mr-2" size={16} />
                <span>{session.hall.name}, {session.format}</span>
              </div>
              <div className="flex items-center">
                <Ticket className="text-neon-pink mr-2" size={16} />
                <span>{booking.seats.length} {getTicketWord(booking.seats.length)}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {booking.seats.sort().map(seat => {
            const [row, seatNum] = seat.split('-');
            return (
              <div key={seat} className="px-3 py-1 bg-space-purple bg-opacity-20 border border-space-purple rounded-md text-sm">
                Ряд {row}, Место {seatNum}
              </div>
            );
          })}
        </div>
        
        <div className="flex justify-between items-center border-t border-space-purple pt-4">
          <div className="text-lg font-semibold">{booking.totalPrice} ₸</div>
          
          {!isPast && !isCancelled && (
            <div className="flex gap-3">
              <Link
                to={`/confirmation/${booking.id}`}
                className="neon-button blue text-sm py-1 px-4"
              >
                Детали
              </Link>
              <button
                onClick={() => handleCancelBooking(booking.id)}
                className="neon-button pink text-sm py-1 px-4"
              >
                Отменить
              </button>
            </div>
          )}
          
          {(isPast || isCancelled) && (
            <span className="text-gray-400 text-sm">
              {isCancelled ? 'Отменено' : 'Сеанс завершен'}
            </span>
          )}
        </div>
      </motion.div>
    );
  };
  
  // Функция для правильного склонения слова "билет"
  const getTicketWord = (count: number) => {
    if (count === 1) return 'билет';
    if (count >= 2 && count <= 4) return 'билета';
    return 'билетов';
  };

  return (
    <div className="pb-12">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Кнопка "Назад" */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => navigate('/')}
            className="flex items-center text-gray-400 hover:text-neon-blue transition-colors"
          >
            <ArrowLeft className="mr-1" size={18} />
            На главную
          </button>
          
          <button
            onClick={handleLogout}
            className={`flex items-center text-gray-400 hover:text-neon-pink transition-colors ${isLoggingOut ? 'opacity-50 pointer-events-none' : ''}`}
            disabled={isLoggingOut}
          >
            <LogOut className="mr-1" size={18} />
            Выйти
          </button>
        </div>
        
        {/* Профиль пользователя */}
        <div className="cinema-card mb-8">
          <div className="flex items-center">
            <div className="w-16 h-16 bg-neon-purple bg-opacity-20 rounded-full flex items-center justify-center mr-4">
              <User className="text-neon-purple" size={32} />
            </div>
            <div>
              <h1 className="text-2xl font-bold mb-1">{user?.name}</h1>
              <p className="text-gray-400">{user?.email}</p>
            </div>
          </div>
        </div>
        
        {/* Вкладки */}
        <div className="flex border-b border-space-purple mb-6">
          <button
            onClick={() => setActiveTab('active')}
            className={`px-6 py-3 border-b-2 transition-colors ${
              activeTab === 'active'
                ? 'border-neon-pink text-white'
                : 'border-transparent text-gray-400 hover:text-gray-300'
            }`}
          >
            Активные бронирования
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-6 py-3 border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-neon-pink text-white'
                : 'border-transparent text-gray-400 hover:text-gray-300'
            }`}
          >
            История
          </button>
        </div>
        
        {/* Список бронирований */}
        <div className="space-y-6">
          {activeTab === 'active' && (
            activeBookings.length > 0 ? (
              activeBookings.map(booking => renderBookingCard(booking.id))
            ) : (
              <div className="cinema-card p-8 text-center">
                <Ticket className="mx-auto mb-4 text-neon-blue" size={32} />
                <h3 className="text-xl font-semibold mb-2">У вас нет активных бронирований</h3>
                <p className="text-gray-300 mb-6">Забронируйте билеты на любимый фильм прямо сейчас!</p>
                <Link to="/" className="neon-button pink">
                  Смотреть афишу
                </Link>
              </div>
            )
          )}
          
          {activeTab === 'history' && (
            historyBookings.length > 0 ? (
              historyBookings.map(booking => renderBookingCard(booking.id))
            ) : (
              <div className="cinema-card p-8 text-center">
                <Calendar className="mx-auto mb-4 text-neon-blue" size={32} />
                <h3 className="text-xl font-semibold mb-2">История бронирований пуста</h3>
                <p className="text-gray-300">Здесь будут отображаться ваши прошедшие и отмененные бронирования</p>
              </div>
            )
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default ProfilePage;