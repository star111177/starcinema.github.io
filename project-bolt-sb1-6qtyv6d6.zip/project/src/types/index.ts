// Типы для фильмов
export interface Movie {
  id: string;
  title: string;
  originalTitle: string;
  posterUrl: string;
  rating: number;
  year: number;
  director: string;
  duration: number; // В минутах
  ageRestriction: string;
  genres: string[];
  cast: string[];
  description: string;
  trailerUrl?: string;
}

// Типы для жанров
export interface Genre {
  id: string;
  name: string;
}

// Типы для сеансов
export interface Session {
  id: string;
  movieId: string;
  date: string; // ISO строка даты и времени
  format: string; // '2D', '3D', 'IMAX', etc.
  hall: {
    id: string;
    name: string;
  };
  price: number;
  occupiedSeats: string[]; // В формате "ряд-место", например "7-12"
}

// Типы для пользователей
export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; // Опционально, не должно передаваться на клиент
}

// Типы для бронирования
export interface Booking {
  id: string;
  userId: string;
  movieId: string;
  sessionId: string;
  seats: string[]; // Массив мест в формате "ряд-место"
  totalPrice: number;
  bookingDate: string; // ISO строка даты бронирования
  status: 'confirmed' | 'cancelled';
}